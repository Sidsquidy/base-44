import { base44 } from './base44Client';


export const Project = base44.entities.Project;

export const Photo = base44.entities.Photo;



// auth sdk:
export const User = base44.auth;